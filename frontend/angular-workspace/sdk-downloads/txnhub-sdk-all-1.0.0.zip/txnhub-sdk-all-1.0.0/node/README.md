# TXN HUB Node.js SDK 1.0.0

Requirements: Node.js 18+.

No runtime dependencies are required.

```js
import { TxnHubClient } from '@txnhub/sdk';

const client = await TxnHubClient.fromPrivateKeyFile({
  baseUrl: 'http://localhost:8086',
  merchantId: process.env.TXNHUB_MERCHANT_ID,
  keyId: process.env.TXNHUB_KEY_ID,
  privateKeyPath: process.env.TXNHUB_PRIVATE_KEY_PATH
});

const result = await client.createPayment({
  merchantOrderId: 'ORDER-10001', amountMinor: 2000, currency: 'MMK',
  description: 'Merchant payment', providerCode: 'ABANK_APLUS', providerOptions: {}
});
```

Each HTTP attempt gets a fresh timestamp, nonce and signature. Reuse the same idempotency key only for a retry of the same business operation.

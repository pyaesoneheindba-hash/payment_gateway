# TXN HUB Python SDK 1.0.0

Requirements: Python 3.10+ and `cryptography`.

```bash
pip install -e .
```

```python
from txnhub_sdk import TxnHubClient
client = TxnHubClient.from_private_key_file(
    "http://localhost:8086", merchant_id, key_id, private_key_path
)
result = client.create_payment({
    "merchantOrderId": "ORDER-10001", "amountMinor": 2000, "currency": "MMK",
    "description": "Merchant payment", "providerCode": "ABANK_APLUS", "providerOptions": {}
})
```

Signing and the HTTP request are performed in one call. The merchant private key never goes to TXN HUB.

# TXN HUB .NET SDK 1.0.0

Requirements: .NET 8+.

The SDK uses `BouncyCastle.Cryptography` for Ed25519 PKCS#8 support and `HttpClient` for transport.

```csharp
var client = TxnHubClient.FromPrivateKeyFile(
    "http://localhost:8086", merchantId, keyId, privateKeyPath);

var response = await client.CreatePaymentAsync(new {
    merchantOrderId = "ORDER-10001", amountMinor = 2000, currency = "MMK",
    description = "Merchant payment", providerCode = "ABANK_APLUS", providerOptions = new { }
});
```

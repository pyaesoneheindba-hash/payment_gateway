# TXN HUB PGSIG1 request-signing protocol

Version: 1

PGSIG1 authenticates trusted merchant server-to-server requests to TXN HUB. Merchant private keys stay with the merchant. TXN HUB stores only the corresponding Ed25519 public key.

## Required headers

```text
X-Merchant-Id: <merchant UUID>
X-Key-Id: <registered key ID>
X-Timestamp: <Unix epoch seconds>
X-Nonce: <unique 16..128 character value>
Idempotency-Key: <required by create/refund/void and other idempotent business operations>
Content-Digest: sha-256=:<base64 SHA-256 of exact body bytes>:
X-Signature: <base64 Ed25519 signature>
```

## Canonical input

Sign the following UTF-8 bytes exactly, with `\n` between fields and no trailing newline:

```text
PGSIG1
<UPPERCASE METHOD>
<RAW PATH>
<RAW QUERY STRING OR EMPTY>
<X-Merchant-Id>
<X-Key-Id>
<X-Timestamp>
<X-Nonce>
<Idempotency-Key OR EMPTY>
<Content-Digest>
```

The request body hashed into `Content-Digest` must be byte-for-byte identical to the body sent on the wire. Do not reserialize JSON after signing.

## Replay and retry behavior

- Every HTTP attempt uses a fresh timestamp, nonce, and signature.
- A legitimate retry of the same business operation reuses the same `Idempotency-Key` and request body, but generates a new timestamp/nonce/signature.
- Replaying an identical signed request should be rejected with `REQUEST_REPLAY_DETECTED`.
- Keep merchant private keys outside source control and preferably in an HSM, KMS, secrets manager, or restricted key file.

## Webhook verification

Gateway webhooks use a different protocol, `PGWH1`:

```text
PGWH1
<X-Payment-Event-Id>
<X-Payment-Timestamp>
<Content-Digest>
```

Verify `Content-Digest` against the exact received body and verify `X-Payment-Signature` with the TXN HUB webhook public key. Deduplicate on event ID.

## Conformance vector

See `../test-vectors/vector.json`. The private key in `test-vectors` is deliberately public test material and must never be used in a real environment.

# TXN HUB Java SDK 1.0.0

Requirements: JDK 17+ and Maven 3.9+.

```java
TxnHubClient client = new TxnHubClient(
    "http://localhost:8086",
    System.getenv("TXNHUB_MERCHANT_ID"),
    System.getenv("TXNHUB_KEY_ID"),
    Path.of(System.getenv("TXNHUB_PRIVATE_KEY_PATH"))
);

String idem = TxnHubClient.newIdempotencyKey();
TxnHubResponse response = client.createPayment(Map.of(
    "merchantOrderId", "ORDER-10001",
    "amountMinor", 2000,
    "currency", "MMK",
    "description", "Merchant payment",
    "providerCode", "ABANK_APLUS",
    "providerOptions", Map.of()
), idem);

System.out.println(response.body());
```

The SDK signs and sends one HTTP request. The private key remains local.

For business retries, reuse the same `Idempotency-Key` and same body; the SDK creates a fresh nonce, timestamp and signature on every HTTP attempt.

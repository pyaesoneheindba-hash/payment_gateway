package com.txnhub.sdk;

public class TxnHubException extends RuntimeException {
    private final int statusCode;
    private final String responseBody;

    public TxnHubException(int statusCode, String responseBody) {
        super("TXN HUB request failed with HTTP " + statusCode + ": " + responseBody);
        this.statusCode = statusCode;
        this.responseBody = responseBody;
    }

    public TxnHubException(String message, Throwable cause) {
        super(message, cause);
        this.statusCode = 0;
        this.responseBody = null;
    }

    public int statusCode() { return statusCode; }
    public String responseBody() { return responseBody; }
}

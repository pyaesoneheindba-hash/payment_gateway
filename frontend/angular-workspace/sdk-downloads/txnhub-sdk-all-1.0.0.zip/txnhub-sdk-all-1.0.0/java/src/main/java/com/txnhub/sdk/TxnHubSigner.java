package com.txnhub.sdk;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.KeyFactory;
import java.security.MessageDigest;
import java.security.PrivateKey;
import java.security.Signature;
import java.security.spec.PKCS8EncodedKeySpec;
import java.util.Base64;

final class TxnHubSigner {
    private final PrivateKey privateKey;

    TxnHubSigner(Path privateKeyPem) {
        try {
            String pem = Files.readString(privateKeyPem, StandardCharsets.US_ASCII)
                    .replace("-----BEGIN PRIVATE KEY-----", "")
                    .replace("-----END PRIVATE KEY-----", "")
                    .replaceAll("\\s", "");
            byte[] der = Base64.getDecoder().decode(pem);
            this.privateKey = KeyFactory.getInstance("Ed25519").generatePrivate(new PKCS8EncodedKeySpec(der));
        }
        catch (Exception e) { throw new TxnHubException("Could not load Ed25519 PKCS#8 private key", e); }
    }

    static String contentDigest(byte[] body) {
        try {
            byte[] digest = MessageDigest.getInstance("SHA-256").digest(body);
            return "sha-256=:" + Base64.getEncoder().encodeToString(digest) + ":";
        }
        catch (Exception e) { throw new TxnHubException("SHA-256 is unavailable", e); }
    }

    String sign(String canonical) {
        try {
            Signature signer = Signature.getInstance("Ed25519");
            signer.initSign(privateKey);
            signer.update(canonical.getBytes(StandardCharsets.UTF_8));
            return Base64.getEncoder().encodeToString(signer.sign());
        }
        catch (Exception e) { throw new TxnHubException("Could not sign TXN HUB request", e); }
    }

    static String canonical(String method, String rawPath, String rawQuery, String merchantId,
                            String keyId, String timestamp, String nonce, String idempotencyKey,
                            String contentDigest) {
        return String.join("\n", "PGSIG1", method.toUpperCase(), rawPath,
                rawQuery == null ? "" : rawQuery,
                merchantId, keyId, timestamp, nonce,
                idempotencyKey == null ? "" : idempotencyKey, contentDigest);
    }
}

# TXN HUB Merchant SDKs

SDK version: **1.0.0**

This folder contains reference merchant SDKs that implement the same PGSIG1 Ed25519 request-signing protocol used by the TXN HUB API Gateway.

| SDK | Runtime | Crypto/HTTP dependencies |
|---|---|---|
| Java | JDK 17+ | JDK crypto + `java.net.http`; Jackson for JSON convenience |
| Node.js | Node 18+ | Built-in `crypto` and `fetch` |
| PHP | PHP 8.1+ | `sodium` and `curl` extensions |
| Python | Python 3.10+ | `cryptography`; standard-library HTTP |
| .NET | .NET 8+ | `BouncyCastle.Cryptography`; `HttpClient` |

All SDKs provide the same core workflow:

1. Load the merchant's PKCS#8 Ed25519 private key locally.
2. Serialize the request body once.
3. Calculate `Content-Digest`.
4. Build PGSIG1 canonical input.
5. Sign with Ed25519.
6. Send the signed HTTP request directly to TXN HUB.
7. Verify TXN HUB webhook signatures using PGWH1.

The SDK does **not** send a preliminary request to obtain a curl command. Signing happens locally in the merchant application and the SDK sends one signed HTTP request to TXN HUB.

## Credentials

A merchant application needs:

```text
base URL      supplied by TXN HUB for UAT/Production
merchant ID   shown in Merchant Portal
key ID        registered in Merchant Portal
private key   kept only by the merchant
```

## Security

Never commit merchant private keys to Git. Do not upload them to TXN HUB. Production merchants should prefer a secrets manager, HSM, KMS, or a restricted filesystem location.

For retry behavior and exact canonicalization, read `spec/PGSIG1.md`.
